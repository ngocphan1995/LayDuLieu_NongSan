<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
  <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.2/raphael-min.js"></script>
  <script src="bieudo/morris.js" type="text/javascript"></script>
  <script src="http://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.js"></script>
  <link href="bieudo/style.css" rel="stylesheet" type="text/css"/>
  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.css">
  <link href="bieudo/morris.css" rel="stylesheet" type="text/css"/>
  <script src="bieudo/example.js" type="text/javascript"></script>
  

<link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
<h6><a href="index.php">Quay lại</a></h6>
<form id="form-search" method="post" action="">
    <div class="row">
    <div class="col-md-3">Nhập tên sản phẩm </div>
    <div class="col-md-4"><input type="text" class="form-control" name="search"></div>
    
    
     <div class="col-md-5"><select name="tinh">
                <option value="0">Chọn Tỉnh</option>
                <option value="Hà Nội">Hà Nội</option>
                <option value="Thái Nguyên">Thái Nguyên</option>
                <option value="Hưng Yên">Hưng Yên</option>
                <option value="An Giang">An Giang </option>
                <option value="Tiền Giang">Tiền Giang</option>
            </select></div>
    </div>
    <div class="col-md-1">
        <input type="submit" value="Tìm kiếm" name="timkiem" id="timkiem">
    </div>
</form>
<?php

       /* while($sp)
        {
            $gia=$sp->Gia;
            echo "giá của sản phẩm".$sp->TenMatHang."là:".$gia."thời gian cập nhật".$sp->NgayCapNhat."tỉnh:".$sp->Tinh."<br/>";
           
        }*/

?>

<?php 
$tensp="";
if(isset($_POST["timkiem"]))
{
    $tensp=$_POST["search"];
   
    $tinh=$_POST["tinh"];
}
if($tensp!="")
{
include_once 'connect.php';
 $sql="SELECT * FROM `sanpham` where TenMatHang like '%$tensp%' and Tinh like '%$tinh%'";
        $sth=$conn->query($sql);
        $sth->setFetchMode(PDO::FETCH_OBJ);
        
$sp=$sth->fetch();
if($sp!=NULL)
{?>
<br/>
<h4 style="text-align: center">Biểu đồ cho <?php echo $sp->TenMatHang ?> tại tỉnh <?php echo $sp->Tinh ?> </h4>
    <div id="myfirstchart" style="height: 250px;"></div>
<pre id="code" class="prettyprint linenums">
new Morris.Line({
  // ID of the element in which to draw the chart.
  element: 'myfirstchart',
  // Chart data records -- each entry in this array corresponds to a point on
  // the chart.

  data: [
<?php while($sp)
        {?>
    { year: '<?php echo $sp->NgayCapNhat?>', value: <?php echo $sp->Gia ?> },
<?php  $sp=$sth->fetch();}?>
 ],
  // The name of the data record attribute that contains x-values.
  xkey: 'year',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Value']
});
</pre>
        <?php }
else
    echo "Không có sản phẩm nào";
        }?>

    
 
